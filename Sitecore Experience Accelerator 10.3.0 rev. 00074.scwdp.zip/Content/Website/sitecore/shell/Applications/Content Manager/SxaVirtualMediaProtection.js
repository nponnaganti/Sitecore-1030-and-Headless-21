"use strict";
var SXA;
(function (SXA) {
    var Foundation;
    (function (Foundation) {
        var Multisite;
        (function (Multisite) {
            var HtmlHelpers = (function () {
                function HtmlHelpers() {
                }
                HtmlHelpers.addProxyToObject = function (obj, functionName, proxyFn) {
                    var proxied = obj[functionName];
                    obj[functionName] = function () {
                        var result = proxied.apply(this, arguments);
                        proxyFn(arguments);
                        return result;
                    };
                };
                HtmlHelpers.getFirstParentWithClass = function (target, className) {
                    var parent = target.parentElement;
                    while (parent != null && !parent.classList.contains(className)) {
                        parent = parent.parentElement;
                    }
                    return parent;
                };
                return HtmlHelpers;
            }());
            Multisite.HtmlHelpers = HtmlHelpers;
            var SxaVirtualMediaProtection = (function () {
                function SxaVirtualMediaProtection() {
                    this.paramName = "_SXAVM";
                    this.contentTreeNodeId = "Tree_Glyph_0DE95AE441AB4D019EB067441B7C2450";
                }
                SxaVirtualMediaProtection.prototype.handle = function (args) {
                    var target = args[1];
                    var sxaArg = document.querySelector("#" + this.paramName);
                    if (!sxaArg) {
                        var input = this.createSxaVmInput(target);
                        document.getElementById("ContentEditorForm").appendChild(input);
                    }
                    else {
                        sxaArg.value = this.getSxaVmValue(target);
                    }
                };
                SxaVirtualMediaProtection.prototype.createSxaVmInput = function (target) {
                    var input = document.createElement("input");
                    input.setAttribute("type", "hidden");
                    input.setAttribute("name", this.paramName);
                    input.setAttribute("id", this.paramName);
                    input.setAttribute("value", this.getSxaVmValue(target));
                    return input;
                };
                SxaVirtualMediaProtection.prototype.getSxaVmValue = function (target) {
                    if (target.classList.contains("scDragHover")) {
                        return "content";
                    }
                    var className = "scContentTreeNode";
                    var parentElement = HtmlHelpers.getFirstParentWithClass(HtmlHelpers.getFirstParentWithClass(target, className), className);
                    var belowMedia = null;
                    if (parentElement.querySelector("span img")) {
                        for (var i = 0; i < parentElement.childNodes.length; i++) {
                            var cur = parentElement.childNodes[i];
                            if (cur.nodeName === "A" && cur.innerText === "Media") {
                                belowMedia = cur.id;
                            }
                        }
                    }
                    var parent = target.parentElement;
                    while (parent != null) {
                        if (parent.classList.contains("scContentTreeNode")) {
                            var child = parent.children[0];
                            if (child) {
                                if (child.id === this.contentTreeNodeId) {
                                    if (belowMedia) {
                                        return "content|" + belowMedia;
                                    }
                                    else {
                                        return "";
                                    }
                                }
                            }
                        }
                        parent = parent.parentElement;
                    }
                    return "";
                };
                return SxaVirtualMediaProtection;
            }());
            Multisite.SxaVirtualMediaProtection = SxaVirtualMediaProtection;
        })(Multisite = Foundation.Multisite || (Foundation.Multisite = {}));
    })(Foundation = SXA.Foundation || (SXA.Foundation = {}));
})(SXA || (SXA = {}));
var Multisite = SXA.Foundation.Multisite;
Multisite.HtmlHelpers.addProxyToObject(scContent.dragDropManager, "onNodeDrop", function (a) { new Multisite.SxaVirtualMediaProtection().handle(a); });
