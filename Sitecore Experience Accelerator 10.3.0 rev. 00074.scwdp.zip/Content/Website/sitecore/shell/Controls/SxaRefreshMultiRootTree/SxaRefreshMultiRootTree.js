﻿if (typeof (Sitecore) != "undefined" || Sitecore.Treeview) {
    var interval = 50;
    function waitForActiveNodeAndClick() {
        var els = document.querySelectorAll(".sxaRefreshTree .scContentTreeNodeActive");
        var activeTreeNode = [].slice.call(els).pop();

        if (activeTreeNode) {
            activeTreeNode.click();
        } else {
            setTimeout(function() {
                waitForActiveNodeAndClick();
            }, interval);
        }
    }
    waitForActiveNodeAndClick();
}