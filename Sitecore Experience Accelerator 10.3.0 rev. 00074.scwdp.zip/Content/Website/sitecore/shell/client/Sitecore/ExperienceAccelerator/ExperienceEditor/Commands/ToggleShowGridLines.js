﻿define(["sitecore", "/-/speak/v1/ExperienceEditor/ExperienceEditor.js"], function (Sitecore, ExperienceEditor) {
    //initializer helper
    var initializeHelper = function (initializeFunction) {
        var trialsCount = 1,
            tryInitialize,
            initSuccess = false;
        tryInitialize = setInterval(function () {
            if (initSuccess && typeof (tryInitialize) !== "undefined") {
                clearInterval(tryInitialize);
                return;
            }

            try {
                initializeFunction();
                initSuccess = true;
            } catch (ex) {
                if (++trialsCount > 20) {
                    clearInterval(tryInitialize);
                }
                return;
            }
        }, 500);
    },
    shouldInitialize = false;
    //initializer helper end
    Sitecore.Commands.ToggleShowGridLines =
    {
        canExecute: function (context, parent) {
            var requestContext = context.app.clone(context.currentContext);
            var limitedDevice = context.app.canExecute("ExperienceEditor.XA.CheckDeviceLimited", requestContext);
            if (limitedDevice) {
                parent.initiator.set({ isVisible: false });
                return false;
            }

            var self = this,
                isChecked = context.button.get("isChecked") == "1";

            if (isChecked) {
                ExperienceEditor.PipelinesUtil.generateRequestProcessor("ExperienceEditor.XA.GetGridColumnClass", function (response) {
                    self.register(response.responseValue.value.className, response.responseValue.value.grid);
                }).execute(context);
            }
            return true;
        },
        execute: function (context) {
            var self = this;
            ExperienceEditor.PipelinesUtil.generateRequestProcessor("ExperienceEditor.ToggleRegistryKey.Toggle", function (response) {
                response.context.button.set("isChecked", response.responseValue.value ? "1" : "0");

                if (response.responseValue.value) {
                    ExperienceEditor.PipelinesUtil.generateRequestProcessor("ExperienceEditor.XA.GetGridColumnClass", function (response) {
                        self.register(response.responseValue.value.className, response.responseValue.value.grid);
                    }).execute(context);
                }
                else {
                    self.unregister();
                }
                //
            }, { value: context.button.get("registryKey") }).execute(context);
        },
        isCheckedAndEnabled: function (commandName) {
            var command = ExperienceEditor.CommandsUtil.getControlsByCommand(ExperienceEditor.getContext().instance.Controls, commandName);
            if (command.length > 0 && command[0] && command[0].model) {
                return command[0].model.get("isEnabled") == "1" && command[0].model.get("isChecked") == "1";
            }
            return false;
        },
        register: function (columnsize, grid) {
            shouldInitialize = true;
            initializeHelper(function () {
                if (shouldInitialize) {
                    window.parent.$xa.gridlines.init(columnsize, grid);
                }
            });
        },
        unregister: function () {
            shouldInitialize = false;
            initializeHelper(function () {
                if (!shouldInitialize) {
                    window.parent.$xa.gridlines.remove();
                }
            });
        }
    };
});