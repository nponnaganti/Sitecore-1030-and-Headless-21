﻿define(
  [
    "sitecore"
  ],
  function () {
      var taxonomy = {
      };
      taxonomy.templates = {
          _Taggable: "{F39A594A-7BC9-4DB0-BAA1-88543409C1F9}"
      }
      return taxonomy;
  });