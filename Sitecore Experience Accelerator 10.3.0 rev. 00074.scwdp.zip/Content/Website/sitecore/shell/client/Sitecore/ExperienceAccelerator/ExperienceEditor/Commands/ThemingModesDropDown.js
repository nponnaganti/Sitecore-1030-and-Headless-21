﻿define(["sitecore", "/-/speak/v1/ExperienceEditor/ExperienceEditor.js", "/-/speak/v1/ExperienceEditor/sxaHelper.js", "/-/speak/v1/Presentation/Presentation.js"], function (Sitecore, ExperienceEditor, SxaHelper, presentation) {
    Sitecore.Commands.ThemeModeDropDown =
    {
        canExecute: function (context) {
            var requestContext = context.app.clone(context.currentContext);
            var canEdit = context.app.canExecute("ExperienceEditor.XA.CanSetViewMode", requestContext);
            return canEdit;
        },
        execute: function (context) {
            var requestContext = context.app.clone(context.currentContext);
            requestContext.value = context.currentContext.argument;
            ExperienceEditor.PipelinesUtil.generateRequestProcessor("ExperienceEditor.XA.SetThemeMode", function (response) {
                window.top.location.reload();
            }, requestContext).execute(context);
        }
    };
});