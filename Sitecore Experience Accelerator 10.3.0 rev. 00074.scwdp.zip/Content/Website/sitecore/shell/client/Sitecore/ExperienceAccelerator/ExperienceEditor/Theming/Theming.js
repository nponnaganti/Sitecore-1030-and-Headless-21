﻿define(
  [
    "sitecore"
  ],
  function () {
      var theming = {
      };
      theming.templates = {
          SiteTheme: "{1479D1EC-DE94-4546-B02F-84636B2061C2}"
      }
      return theming;
  });