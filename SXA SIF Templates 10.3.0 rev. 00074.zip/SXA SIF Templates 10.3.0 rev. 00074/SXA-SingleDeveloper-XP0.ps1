# The Prefix used on SOLR, Website and Database instances.
$prefix = "XP0"
# The Password for the Sitecore Admin User
$SitecoreAdminPassword = "b"
# The root folder with the license file and WDP files.
$SCInstallRoot = "C:\ResourceFiles"
# The URL of the Solr Server
$SolrUrl = "https://localhost:8996/solr"
# The Folder that Solr has been installed in.
$SolrRoot = "C:\Solr-8.11.1"
# The Name of the Solr Service.
$SolrService = "Solr-8.11.1"
# The DNS name or IP of the SQL Instance.
$SqlServer = "localhost"
# A SQL user with sysadmin privileges.
$SqlAdminUser = "sa"
# The password for $SQLAdminUser.
$SqlAdminPassword = "12345"
# The name for the Sitecore Content Delivery server.
$Sitename = "$prefix.sc"

$SPEPackage = (Get-ChildItem "$SCInstallRoot\Sitecore.PowerShell.Extensions*.scwdp.zip").FullName
$SXAPackage = (Get-ChildItem "$SCInstallRoot\Sitecore Experience Accelerator*.scwdp.zip").FullName

# Install Sitecore Powershell and Experience Accelerator packages
$sitecoreParams = @{
    Path                      = "$SCInstallRoot\SXA-SingleDeveloper-XP0.json"
    SPEPackage                = $SPEPackage
    SXAPackage                = $SXAPackage
    Prefix                    = $prefix
    SitecoreAdminPassword     = $SitecoreAdminPassword
    SqlServer                 = $SqlServer
    SqlAdminUser              = $SqlAdminUser
    SqlAdminPassword          = $SqlAdminPassword
    SolrUrl                   = $SolrUrl
    SolrRoot                  = $SolrRoot
    SolrService               = $SolrService
    Sitename                  = $Sitename
}

Push-Location $SCInstallRoot

Install-SitecoreConfiguration @sitecoreParams -verbose *>&1 | Tee-Object SXA-SingleDeveloper.log

Pop-Location