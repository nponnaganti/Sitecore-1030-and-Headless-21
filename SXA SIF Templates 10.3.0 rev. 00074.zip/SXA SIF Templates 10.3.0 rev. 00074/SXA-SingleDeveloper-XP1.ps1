# The Prefix used on SOLR, Website and Database instances.
$prefix = "XP1"
# The Password for the Sitecore Admin User
$SitecoreAdminPassword = "b"
# The root folder with the license file and WDP files.
$SCInstallRoot = "C:\ResourceFiles"
# The URL of the Solr Server
$SolrUrl = "https://localhost:8996/solr"
# The Folder that Solr has been installed in.
$SolrRoot = "C:\Solr-8.11.1"
# The Name of the Solr Service.
$SolrService = "Solr-8.11.1"
# The DNS name or IP of the SQL Instance.
$SqlServer = "localhost"
# A SQL user with sysadmin privileges.
$SqlAdminUser = "sa"
# The password for $SQLAdminUser.
$SqlAdminPassword = "12345"
# The name for the Sitecore Content Management server.
$CMSitename = "$prefix.cm"
# The name for the Sitecore Content Delivery server.
$CDSiteName = "$prefix.cd"

$SPEPackage = (Get-ChildItem "$SCInstallRoot\Sitecore.PowerShell.Extensions*.scwdp.zip").FullName
$SXACMPackage = (Get-ChildItem "$SCInstallRoot\Sitecore Experience Accelerator*.scwdp.zip" -Exclude "*CD*").FullName
$SXACDPackage = (Get-ChildItem "$SCInstallRoot\Sitecore Experience Accelerator*.scwdp.zip" -Include "*CD*").FullName

# Install Sitecore Powershell and Experience Accelerator packages
$sitecoreParams = @{
    Path                      = "$SCInstallRoot\SXA-SingleDeveloper-XP1.json"
    SPEPackage                = $SPEPackage
    SXACMPackage              = $SXACMPackage
    SXACDPackage              = $SXACDPackage
    Prefix                    = $prefix
    SitecoreAdminPassword     = $SitecoreAdminPassword
    SqlServer                 = $SqlServer
    SqlAdminUser              = $SqlAdminUser
    SqlAdminPassword          = $SqlAdminPassword
    SolrUrl                   = $SolrUrl
    SolrRoot                  = $SolrRoot
    SolrService               = $SolrService
    SitecoreContentManagementSiteName                  = $CMSitename
    SitecoreContentDeliverySiteName                    = $CDSiteName
}

Push-Location $SCInstallRoot

Install-SitecoreConfiguration @sitecoreParams -verbose *>&1 | Tee-Object SXA-SingleDeveloper.log

Pop-Location